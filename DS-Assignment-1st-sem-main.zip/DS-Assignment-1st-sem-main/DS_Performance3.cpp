#include <iostream> 
using namespace std;

int main()
{
    int marks[5];
    
    cout << "Enter marks of 5 students:\n"; 
    
    for (int i = 0; i < 5; i++)
    {
        cin >> marks[i];
    } 
    
    
    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < 4 - i; j++)
        { 
           if (marks[j] < marks[j + 1])
           {
               int temp = marks[j]; 
               marks[j] = marks[j + 1];
               marks[j + 1] = temp;
           }
        }
    }
    
    cout << "\nStudent Ranking based on Marks:\n";
    
    for (int i = 0; i < 5; i++) 
    {
        cout << marks[i] << endl;
    }
         return 0;
} 

Output:
Enter marks of 5 students:
90
55
80
81
92

Student Ranking based on Marks:
92
90
81
80
55
